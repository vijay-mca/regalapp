import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { NgxSpinnerModule } from "ngx-spinner";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { MapComponent } from "./component/map/map.component";
import { BackToHomeComponent } from "./component/back-to-home/back-to-home.component";
import { CareHomeDetailsComponent } from "./component/care-home-details/care-home-details.component";
import { CareHomeComponent } from "./component/care-home/care-home.component";
import { CaseStudiesComponent } from "./component/case-studies/case-studies.component";
import { DownmenuComponent } from "./component/downmenu/downmenu.component";
import { HomeComponent } from "./component/home/home.component";
import { KnowledgeBankDetailsComponent } from "./component/knowledge-bank-details/knowledge-bank-details.component";
import { KnowledgeBankComponent } from "./component/knowledge-bank/knowledge-bank.component";
import { LoginComponent } from "./component/login/login.component";
import { RegisterComponent } from "./component/register/register.component";
import { SidebarComponent } from "./component/sidebar/sidebar.component";
import { SpinnerComponent } from "./component/spinner/spinner.component";

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    CaseStudiesComponent,
    KnowledgeBankComponent,
    CareHomeComponent,
    CareHomeDetailsComponent,
    MapComponent,
    SidebarComponent,
    DownmenuComponent,
    KnowledgeBankDetailsComponent,
    SpinnerComponent,
    BackToHomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgbModule,
    NgxSpinnerModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
