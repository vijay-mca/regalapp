import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class CommonService {
  public navClass: string = "";

  constructor() {}

  closeNav(): void {
    this.navClass = "w-0";
  }

  openNav(): void {
    this.navClass = "w-85";
  }

  convertUrlEncoded(post: any): void {
    let formBody: any = [];
    for (let property in post) {
      let encodedKey = encodeURIComponent(property);
      let encodedValue = encodeURIComponent(post[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    return formBody;
  }

  setCookie(name: any, value: any): void {
    localStorage.setItem(name, value);
  }
}
