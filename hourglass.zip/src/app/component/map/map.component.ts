import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { CommonService } from "src/app/service/common.service";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import ImageMap from "image-map";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Router } from "@angular/router";

@Component({
  selector: "app-map",
  templateUrl: "./map.component.html",
  styleUrls: ["./map.component.css"],
})
export class MapComponent implements OnInit {
  contentList: any = [];
  contentDetails: any = [];
  countryName: string = "";
  countyName: string = "";
  countyImageDisplayPath: string = "";

  isMobile: boolean = false;

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private modalService: NgbModal,
    private router: Router
  ) {
    if (
      /Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent
      )
    ) {
      this.isMobile = true;
    } else {
      this.isMobile = false;
    }
  }

  ngOnInit(): void {
    ImageMap("img[usemap]", 500);
  }

  onClick1(event: any): void {
    event.preventDefault();
    if (!this.isMobile) {
      this.common.openNav();
      try {
        // this.spinner.show();
        let options: any = {
          headers: new HttpHeaders(REQUEST_HEADER),
        };

        const post: any = {
          auth_username: AUTH_USERNAME,
          auth_password: AUTH_PASSWORD,
          action: "CountyList",
          county_id: 1,
        };

        let formBody: any = this.common.convertUrlEncoded(post);

        this.http.post<any>(API, formBody, options).subscribe((res: any) => {
          const {
            content,
            country_name,
            county_name,
            county_image_display_path,
          }: any = res;

          this.countryName = country_name;
          this.countyName = county_name;
          this.contentList = content;
          this.countyImageDisplayPath = county_image_display_path;

          // this.spinner.hide();
        });
      } catch (error) {
        alert(error);
      }
    } else {
      this.router.navigate(["care-home", 1]);
    }
  }

  onClick2(event: any): void {
    event.preventDefault();
    if (!this.isMobile) {
      this.common.openNav();
      try {
        // this.spinner.show();
        let options: any = {
          headers: new HttpHeaders(REQUEST_HEADER),
        };

        const post: any = {
          auth_username: AUTH_USERNAME,
          auth_password: AUTH_PASSWORD,
          action: "CountyList",
          county_id: 2,
        };

        let formBody: any = this.common.convertUrlEncoded(post);

        this.http.post<any>(API, formBody, options).subscribe((res: any) => {
          const {
            content,
            country_name,
            county_name,
            county_image_display_path,
          }: any = res;

          this.countryName = country_name;
          this.countyName = county_name;
          this.contentList = content;
          this.countyImageDisplayPath = county_image_display_path;

          // this.spinner.hide();
        });
      } catch (error) {
        alert(error);
      }
    } else {
      this.router.navigate(["care-home", 2]);
    }
  }

  onClick3(event: any): void {
    event.preventDefault();
    if (!this.isMobile) {
      this.common.openNav();
      try {
        // this.spinner.show();
        let options: any = {
          headers: new HttpHeaders(REQUEST_HEADER),
        };

        const post: any = {
          auth_username: AUTH_USERNAME,
          auth_password: AUTH_PASSWORD,
          action: "CountyList",
          county_id: 58,
        };

        let formBody: any = this.common.convertUrlEncoded(post);

        this.http.post<any>(API, formBody, options).subscribe((res: any) => {
          const {
            content,
            country_name,
            county_name,
            county_image_display_path,
          }: any = res;

          this.countryName = country_name;
          this.countyName = county_name;
          this.contentList = content;
          this.countyImageDisplayPath = county_image_display_path;

          // this.spinner.hide();
        });
      } catch (error) {
        alert(error);
      }
    } else {
      this.router.navigate(["care-home", 58]);
    }
  }

  onClick4(event: any): void {
    event.preventDefault();``
  }

  setDescription(type: any, value: any): any {
    if (type === 1) {
      return value;
    }
  }

  setImg(type: any, value: any): any {
    if (type == 3) {
      return this.countyImageDisplayPath + value;
    }
  }

  redirectCountyDetails(content_id: any): void {
    this.common.closeNav();
    this.router.navigate(["care-home-details", content_id]);
  }
}
