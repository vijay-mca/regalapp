import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CareHomeDetailsComponent } from './care-home-details.component';

describe('CareHomeDetailsComponent', () => {
  let component: CareHomeDetailsComponent;
  let fixture: ComponentFixture<CareHomeDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CareHomeDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareHomeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
