import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { CommonService } from "src/app/service/common.service";
import {
  API,
  AUTH_PASSWORD,
  AUTH_USERNAME,
  REQUEST_HEADER,
} from "src/environments/environment";

@Component({
  selector: "app-knowledge-bank",
  templateUrl: "./knowledge-bank.component.html",
  styleUrls: ["./knowledge-bank.component.css"],
})
export class KnowledgeBankComponent implements OnInit {
  cmsList: any = [];
  pageTitle: string = "";
  pageDesc: string = "";
  imagePath: string = "";

  loading: boolean = false;
  constructor(
    private http: HttpClient,
    public common: CommonService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit(): void {
    this.cmsContent("Enable");
  }

  cmsContent(status: string): any {
    try {
      this.loading = true;
      this.spinner.show();
      let options: any = {
        headers: new HttpHeaders(REQUEST_HEADER),
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CmsContent",
        status: status,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { result, page_title, page_desc, image_path }: any = res;
        this.cmsList = result;
        this.pageTitle = page_title;
        this.pageDesc = page_desc;
        this.imagePath = image_path;

        this.loading = false;
        this.spinner.hide();
      });
    } catch (error) {
      alert(error);
    }
  }
}
