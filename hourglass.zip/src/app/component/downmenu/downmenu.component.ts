import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downmenu',
  templateUrl: './downmenu.component.html',
  styleUrls: ['./downmenu.component.css']
})
export class DownmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
