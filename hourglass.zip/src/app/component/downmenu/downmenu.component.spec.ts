import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownmenuComponent } from './downmenu.component';

describe('DownmenuComponent', () => {
  let component: DownmenuComponent;
  let fixture: ComponentFixture<DownmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
