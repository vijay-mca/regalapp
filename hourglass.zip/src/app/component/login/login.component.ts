import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { NgxSpinnerService } from "ngx-spinner";
import { CommonService } from "src/app/service/common.service";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  @ViewChild("authModal") private authModalRef: any;

  email: string = "";
  password: string = "";

  inValidEmail: boolean = false;
  inValidPassword: boolean = false;

  unUseEmail: boolean = true;
  unUsePassword: boolean = true;

  status: string = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private spinner: NgxSpinnerService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {}

  onKeyUp(event: any, property: string): void {
    if (property === "email") {
      if (event.target.value === "") {
        this.email = "";
        this.inValidEmail = true;
        this.unUseEmail = true;
      } else {
        this.email = event.target.value;
        this.inValidEmail = false;
        this.unUseEmail = false;
      }
    }

    if (property === "password") {
      if (event.target.value === "") {
        this.password = "";
        this.inValidPassword = true;
        this.unUsePassword = true;
      } else {
        this.password = event.target.value;
        this.inValidPassword = false;
        this.unUsePassword = false;
      }
    }
  }

  login(e: any): any {
    try {
      e.preventDefault();
      this.spinner.show();
      let options: any = {
        headers: new HttpHeaders(REQUEST_HEADER),
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "Login",
        email: this.email,
        password: this.password,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const { status }: any = res;

        if (status === "success") {
          const { mem_id }: any = res;
          this.common.setCookie("hourglass_mem_id", mem_id);
        } else {
          this.status = "Email doesn't exist.!";
          this.modalService.open(this.authModalRef, {
            windowClass: "center-modal",
          });
        }

        this.spinner.hide();
      });
    } catch (error) {
      alert(error);
    }
  }
}
