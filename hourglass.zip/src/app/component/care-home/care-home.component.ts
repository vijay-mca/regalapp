import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { NgxSpinnerService } from "ngx-spinner";
import { CommonService } from "src/app/service/common.service";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";

@Component({
  selector: "app-care-home",
  templateUrl: "./care-home.component.html",
  styleUrls: ["./care-home.component.css"],
})
export class CareHomeComponent implements OnInit {
  contentList: any = [];
  contentDetails: any = [];
  countryName: string = "";
  countyName: string = "";
  countyImageDisplayPath: string = "";
  constructor(
    private http: HttpClient,
    public common: CommonService,
    private modalService: NgbModal,
    private router: Router,
    private spinner: NgxSpinnerService,
    private actRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.countryDetails();
  }

  countryDetails(): void {
    try {
      this.spinner.show();
      let options: any = {
        headers: new HttpHeaders(REQUEST_HEADER),
      };


      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CountyList",
        county_id: this.actRoute.snapshot.params.county_id,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const {
          content,
          country_name,
          county_name,
          county_image_display_path,
        }: any = res;

        this.countryName = country_name;
        this.countyName = county_name;
        this.contentList = content;
        this.countyImageDisplayPath = county_image_display_path;

        this.spinner.hide();
      });
    } catch (error) {
      alert(error);
    }
  }
}
