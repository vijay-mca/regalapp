import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { NgxSpinnerService } from "ngx-spinner";
import { CommonService } from "src/app/service/common.service";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
  APP_VERSION,
} from "src/environments/environment";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"],
})
export class RegisterComponent implements OnInit {
  @ViewChild("registerModal") private registerModalRef: any;

  name: string = "";
  email: string = "";
  phoneNo: string = "";
  password: string = "";

  inValidName: boolean = false;
  inValidEmail: boolean = false;
  inValidPhoneNo: boolean = false;
  inValidPassword: boolean = false;

  unUseName: boolean = true;
  unUseEmail: boolean = true;
  unUsePhoneNo: boolean = true;
  unUsePassword: boolean = true;

  status: string = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {}

  onKeyUp(event: any, property: string): void {
    if (property === "name") {
      if (event.target.value === "") {
        this.name = "";
        this.inValidName = true;
        this.unUseName = true;
      } else {
        this.name = event.target.value;
        this.inValidName = false;
        this.unUseName = false;
      }
    }

    if (property === "email") {
      if (
        !/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(event.target.value) ||
        event.target.value === ""
      ) {
        this.email = "";
        this.inValidEmail = true;
        this.unUseEmail = true;
      } else {
        this.email = event.target.value;
        this.inValidEmail = false;
        this.unUseEmail = false;
      }
    }

    if (property === "phoneNo") {
      if (!/^[0-9]*$/.test(event.target.value) || event.target.value === "") {
        this.phoneNo = "";
        this.inValidPhoneNo = true;
        this.unUsePhoneNo = true;
      } else {
        this.password = event.target.value;
        this.inValidPhoneNo = false;
        this.unUsePhoneNo = false;
      }
    }

    if (property === "password") {
      if (event.target.value === "") {
        this.password = "";
        this.inValidPassword = true;
        this.unUsePassword = true;
      } else {
        this.password = event.target.value;
        this.inValidPassword = false;
        this.unUsePassword = false;
      }
    }
  }

  register(e: any): any {
    try {
      e.preventDefault();
      this.spinner.show();
      let options: any = {
        headers: new HttpHeaders(REQUEST_HEADER),
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "Register",
        name: this.name,
        email: this.email,
        phone_no: this.phoneNo,
        password: this.password,
        type: APP_VERSION,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const { status }: any = res;

        if (status === "success") {
          const { mem_id }: any = res;
          this.common.setCookie("hourglass_mem_id", mem_id);
        } else if (status === "email exist") {
          this.status = "Email already exist.!";
          this.modalService.open(this.registerModalRef, {
            windowClass: "center-modal",
          });
        } else {
          this.status = "Something went wrong. Try again!";
          this.modalService.open(this.registerModalRef, {
            windowClass: "center-modal",
          });
        }

        this.spinner.hide();
      });
    } catch (error) {
      alert(error);
    }
  }
}
