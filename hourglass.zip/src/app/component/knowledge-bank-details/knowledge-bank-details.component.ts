import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { CommonService } from "src/app/service/common.service";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";

@Component({
  selector: "app-knowledge-bank-details",
  templateUrl: "./knowledge-bank-details.component.html",
  styleUrls: ["./knowledge-bank-details.component.css"],
})
export class KnowledgeBankDetailsComponent implements OnInit {
  cmsDetails: any = [];
  pageTitle: string = "";
  pageDesc: string = "";
  imagePath: string = "";

  loading: boolean = false;
  constructor(
    private http: HttpClient,
    public common: CommonService,
    private actRoute: ActivatedRoute,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit(): void {
    this.getCmsDetails(this.actRoute.snapshot.params.id);
  }

  getCmsDetails(cmsId: string): any {
    try {
      this.loading = true;
      this.spinner.show();
      let options: any = {
        headers: new HttpHeaders(REQUEST_HEADER),
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CmsDetails",
        cms_id: cmsId,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { result, page_title, page_desc, image_path }: any = res;
        this.cmsDetails = result;
        this.pageTitle = page_title;
        this.pageDesc = page_desc;
        this.imagePath = image_path;
        
        this.spinner.hide();
        this.loading = false;
      });
    } catch (error) {
      alert(error);
    }
  }
}
