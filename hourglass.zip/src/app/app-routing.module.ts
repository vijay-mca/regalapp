import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CareHomeDetailsComponent } from "./component/care-home-details/care-home-details.component";
import { CareHomeComponent } from "./component/care-home/care-home.component";
import { CaseStudiesComponent } from "./component/case-studies/case-studies.component";
import { DownmenuComponent } from "./component/downmenu/downmenu.component";
import { HomeComponent } from "./component/home/home.component";
import { KnowledgeBankDetailsComponent } from "./component/knowledge-bank-details/knowledge-bank-details.component";
import { KnowledgeBankComponent } from "./component/knowledge-bank/knowledge-bank.component";
import { LoginComponent } from "./component/login/login.component";
import { MapComponent } from "./component/map/map.component";
import { RegisterComponent } from "./component/register/register.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },
  { path: "case-studies", component: CaseStudiesComponent },
  { path: "knowledge-bank", component: KnowledgeBankComponent },
  {
    path: "knowledge-bank-details/:id",
    component: KnowledgeBankDetailsComponent,
  },
  { path: "care-home/:county_id", component: CareHomeComponent },
  { path: "care-home-details/:content_id", component: CareHomeDetailsComponent },
  { path: "map", component: MapComponent },
  { path: "downmenu", component: DownmenuComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
