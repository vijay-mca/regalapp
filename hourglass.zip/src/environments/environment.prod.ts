export const environment = {
  production: true,
};

export const REQUEST_HEADER = {
  "Content-Type": "application/x-www-form-urlencoded",
};
//http://vv5/first/apps/hourglass/
let test = "local";

export const API =
  test === "live"
    ? "http://vv5/first/dionne/hourglass/API/api-v.1.0.0.php"
    : "http://vv5/first/dionne/hourglass/API/api-v.1.0.0.php";

export const AUTH_USERNAME = "Hourglass";
export const AUTH_PASSWORD = "7b5fafa1c12072826389e59f2519dfd0";

export const ANDROID = "Android 1.0.0";
export const IOS = "IOS 1.0.0";

let app = "android";

export const APP_VERSION = app === "ios" ? IOS : ANDROID;

export const MOBILE_MAX_WIDTH = 425;
export const TABLET_MAX_WIDTH = 1024;
