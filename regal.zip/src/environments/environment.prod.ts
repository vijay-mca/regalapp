export const environment = {
  production: true,
};

export const AUTH_USERNAME = "RegalCompetitions";
export const AUTH_PASSWORD = "5e5200a8937f16c7cc8464989e834953";

let mode = "test";

export const API =
  mode === "live"
    ? "https://www.regalcompetitions.com/API/api-v.2.0.2.php"
    : "https://www.regalcompetitions.com/demo/API/api-v.2.0.2.php";

export const REQUEST_HEADER = {
  "Content-Type": "application/x-www-form-urlencoded",
};
