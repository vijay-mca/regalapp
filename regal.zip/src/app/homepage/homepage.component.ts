import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ViewChild } from "@angular/core";
import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import * as moment from 'moment';
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-homepage",
  templateUrl: "./homepage.component.html",
  styleUrls: ["./homepage.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class HomepageComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;

  competitionList: any = [];

  days: any = [];
  hours: any = [];
  minutes: any = [];
  seconds: any = [];
  
  loading: boolean = false;
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    private router: Router,
    public common: CommonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.getCompetitionList();
  }

  getCompetitionList(): void {
    try {
      this.loading = true;
      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = {
        headers: headers,
      };

      let post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CompetitionsList",
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { result }: any = res;
        if (result.length > 0) {
          this.competitionList = result;
          for (let index = 0; index < result.length; index++) {
            this.timer(result[index].end_date, index);
          }
        } else {
          this.competitionList = [];
        }

        this.loading = false;
      });
    } catch (error) {
      this.loading = false;
      this.errMsg = error;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  timer(end_date: any, i: number) {
    setInterval(() => {
      const now = moment();
      const expirydate = moment(end_date);
      const diffr: any = moment.duration(expirydate.diff(now));
      if (diffr > 0) {
        const days: any = parseInt(diffr.asDays());
        const hours: any = parseInt(diffr.asHours()) - days * 24;
        const minutes: any = parseInt(diffr.minutes());
        const seconds: any = parseInt(diffr.seconds());

        this.days[i] = days < 10 ? "0" + days : days;
        this.hours[i] = hours < 10 ? "0" + hours : hours;
        this.minutes[i] = minutes < 10 ? "0" + minutes : minutes;
        this.seconds[i] = seconds < 10 ? "0" + seconds : seconds;
      } else {
        this.days[i] = "00";
        this.hours[i] = "00";
        this.minutes[i] = "00";
        this.seconds[i] = "00";
      }
    });
  }

  redirect(seo_key: any): void {
    this.router.navigate(["detais-page", seo_key]);
  }
}
