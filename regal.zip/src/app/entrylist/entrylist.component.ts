import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import * as moment from "moment";

import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-entrylist",
  templateUrl: "./entrylist.component.html",
  styleUrls: ["./entrylist.component.css"],
})
export class EntrylistComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;

  entryList: any = [];
  moment: any = moment;

  loading: boolean = false;
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.getEntryList();
  }

  getEntryList() {
    try {
      this.loading = true;
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "EntryList",
        unique_id: this.common.getUniqueId(),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { comps } = res;
        this.entryList = comps;
        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }

  ConvertToDate(dateStr: any): any {
    let date = dateStr.substring(0, 10);

    let validDate = date;

    return validDate;
  }

  ConvertToTime(dateStr: any): any {
    let time = dateStr.substring(11, 19);

    let validTime = time;

    return validTime;
  }

  redirect(seo_key: any): void {
    location.href = seo_key;
  }
}
