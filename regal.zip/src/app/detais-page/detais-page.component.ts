import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import * as moment from "moment";
import { OwlOptions } from "ngx-owl-carousel-o";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-detais-page",
  templateUrl: "./detais-page.component.html",
  styleUrls: ["./detais-page.component.css"],
})
export class DetaisPageComponent implements OnInit {
  @ViewChild("cartModal") private cartModalRef: any;
  @ViewChild("alertModal") private alertModalRef: any;
  @ViewChild("successModal") private successModalRef: any;
  @ViewChild("specialCartModal") private specialCartModalRef: any;
  @ViewChild("errorModal") private errorModalRef: any;

  competionDetail: any = {};
  queAns: any = [];
  quantity: any = [];
  totalQuantity: number = 0;
  questionAnswer: any = {};
  specialOffer: any = [];
  specialPrice: any = "";
  specialQuantity: any = "";

  diffr: number;
  days: any = [];
  hours: any = [];
  minutes: any = [];
  seconds: any = [];

  inValidQuantity: boolean = false;
  inValidQuestion: boolean = false;

  unUseQuantity: boolean = true;
  unUseQuestion: boolean = true;

  loading: boolean = false;
  status: any = "";
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    public actRoute: ActivatedRoute,
    private router: Router,
    private modalService: NgbModal
  ) {}

  customOptions: OwlOptions = {
    loop: true,
    autoplay: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: true,
    navSpeed: 700,
    navText: ["", ""],
    responsive: {
      0: {
        items: 1,
      },
      400: {
        items: 1,
      },
      740: {
        items: 1,
      },
      940: {
        items: 2,
      },
    },
    nav: false,
  };

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.getCompetitionDetail();
  }

  getCompetitionDetail(): void {
    try {
      this.loading = true;
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CompetitionsDetails",
        comp_id: this.actRoute.snapshot.params.pro_id,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { result, questionandanswer, special_offer } = res;
        this.competionDetail = result;
        this.queAns = questionandanswer;
        this.specialOffer = special_offer;

        for (let index = 0; index <= result.total_qty_ticket; index++) {
          this.quantity[index] = index;
        }

        this.timer(this.competionDetail.end_date);

        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  timer(end_date: any) {
    setInterval(() => {
      const now = moment();
      const expirydate = moment(end_date);
      const diffr: any = moment.duration(expirydate.diff(now));
      if (diffr > 0) {
        const days: any = parseInt(diffr.asDays());
        const hours: any = parseInt(diffr.asHours()) - days * 24;
        const minutes: any = parseInt(diffr.minutes());
        const seconds: any = parseInt(diffr.seconds());

        this.days = days < 10 ? "0" + days : days;
        this.hours = hours < 10 ? "0" + hours : hours;
        this.minutes = minutes < 10 ? "0" + minutes : minutes;
        this.seconds = seconds < 10 ? "0" + seconds : seconds;
      } else {
        this.days = "00";
        this.hours = "00";
        this.minutes = "00";
        this.seconds = "00";
      }
    });
  }

  openCartModal(): void {
    this.questionAnswer = {};

    this.modalService.open(this.cartModalRef, {
      windowClass: "center-modal",
    });
  }

  onChange(e: any, property: any): void {
    if (property === "quantity") {
      if (Number(e.currentTarget.value) === 0) {
        this.totalQuantity = 0;
        this.inValidQuantity = true;
        this.unUseQuantity = true;
      } else {
        this.totalQuantity = Number(e.currentTarget.value);
        this.inValidQuantity = false;
        this.unUseQuantity = false;
      }
    }

    if (property === "question") {
      let split: any = "";
      if (e.currentTarget.value === "") {
        this.questionAnswer = {};
        this.inValidQuestion = true;
        this.unUseQuestion = true;
      } else {
        split = e.currentTarget.value.split("_");
        this.questionAnswer[0] = { [split[1]]: split[0] };
        this.inValidQuestion = false;
        this.unUseQuestion = false;
      }
    }
  }

  addToCart(pro_id: any, price: any): void {
    try {
      this.modalService.dismissAll();

      this.loading = true;

      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = { headers: headers };

      const post = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "AddToCart",
        member_id: this.common.getMemberId(),
        unique_id: this.common.getUniqueId(),
        product_id: pro_id,
        product_price: price,
        qty: this.totalQuantity,
        question_answer: JSON.stringify(this.questionAnswer),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { status }: any = res;
        this.common.cartRefresh();
        if (status === "exist") {
          this.modalService.open(this.alertModalRef, {
            windowClass: "center-modal",
          });
        } else {
          this.modalService.open(this.successModalRef, {
            windowClass: "center-modal",
          });
        }
        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  specialAddToCartModalOpen(special_quantity: any, special_price: any): void {
    this.specialQuantity = special_quantity;
    this.specialPrice = special_price;

    this.modalService.open(this.specialCartModalRef, {
      windowClass: "center-modal",
    });
  }

  specialAddToCart(
    pro_id: any,
    special_quantity: any,
    special_price: any
  ): void {
    try {
      this.modalService.dismissAll();

      this.loading = true;

      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = { headers: headers };

      const post = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "AddToCart",
        member_id: this.common.getMemberId(),
        unique_id: this.common.getUniqueId(),
        product_id: pro_id,
        product_price: special_price,
        qty: special_quantity,
        question_answer: JSON.stringify(this.questionAnswer),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { status }: any = res;
        this.common.cartRefresh();
        if (status === "exist") {
          this.modalService.open(this.alertModalRef, {
            windowClass: "center-modal",
          });
        } else {
          this.modalService.open(this.successModalRef, {
            windowClass: "center-modal",
          });
        }
        this.loading = false;
        this.specialQuantity = "";
        this.specialPrice = "";
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }
}
