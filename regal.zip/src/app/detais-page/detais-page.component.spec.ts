import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetaisPageComponent } from './detais-page.component';

describe('DetaisPageComponent', () => {
  let component: DetaisPageComponent;
  let fixture: ComponentFixture<DetaisPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetaisPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetaisPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
