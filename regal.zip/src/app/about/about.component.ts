import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ViewChild } from "@angular/core";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-about",
  templateUrl: "./about.component.html",
  styleUrls: ["./about.component.css"],
})
export class AboutComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;

  aboutUs: any = {};
  loading: boolean = false;
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    public actRoute: ActivatedRoute,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.getAbout();
  }

  getAbout() {
    try {
      this.loading = true;
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CMS_Content",
        cms_id: this.actRoute.snapshot.params.cms_id,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        this.aboutUs = res;
        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }
}
