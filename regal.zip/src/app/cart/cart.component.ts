import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-cart",
  templateUrl: "./cart.component.html",
  styleUrls: ["./cart.component.css"],
  encapsulation: ViewEncapsulation.None,
})
export class CartComponent implements OnInit {
  @ViewChild("removeBasketModal") private removeBasketModalRef: any;
  @ViewChild("clearBasketModal") private clearBasketModalRef: any;
  @ViewChild("errorModal") private errorModalRef: any;

  cartItem: any = [];
  basketId: number;
  
  loading: boolean = false;
  errMsg: any = "";
  enableAuth: boolean = false;

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    if (this.common.getMemberId() === 0) {
      this.enableAuth = false;
    } else {
      this.enableAuth = true;
    }

    this.common.cartRefresh();
    this.getCart();
    this.common.cartSummary();
  }

  getCart() {
    try {
      this.loading = true;
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "Cart",
        unique_id: this.common.getUniqueId(),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { result } = res;
        this.cartItem = result;
        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }

  modifyQuantity(
    type: string,
    basket_id: number,
    current_qty: number,
    price: any
  ): void {
    try {
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "ModifyQuantity",
        unique_id: this.common.getUniqueId(),
        type,
        basket_id,
        current_qty,
        price,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { new_qty } = res;
        if (new_qty === 0) {
          this.modalService.open(this.removeBasketModalRef, {
            windowClass: "center-modal",
          });
          this.basketId = basket_id;
        }

        this.getCart();
        this.common.cartSummary();
        this.common.cartRefresh();
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  removeBasket(basket_id: number): any {
    try {
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "RemoveBasket",
        unique_id: this.common.getUniqueId(),
        basket_id,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe(() => {
        this.modalService.dismissAll();
        this.getCart();
        this.common.cartSummary();
        this.common.cartRefresh();
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  clearBasket(): any {
    try {
      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "clearBasket",
        unique_id: this.common.getUniqueId(),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe(() => {
        this.modalService.dismissAll();
        this.getCart();
        this.common.cartSummary();
        this.common.cartRefresh();
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }

  openRemoveBasketModal(basket_id: number): any {
    this.modalService.open(this.removeBasketModalRef, {
      windowClass: "center-modal",
    });
    this.basketId = basket_id;
  }

  openClearBasketModal(): any {
    this.modalService.open(this.clearBasketModalRef, {
      windowClass: "center-modal",
    });
  }

  checkout(): void {
    // location.href = CHECKOUT + '?unique_id=' + this.common.getUniqueId();
    // window.open(CHECKOUT + "?unique_id=" + this.common.getUniqueId());
  }
}
