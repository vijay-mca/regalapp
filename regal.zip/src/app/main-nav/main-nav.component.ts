import { Component, OnInit } from "@angular/core";
import { BreakpointObserver, Breakpoints } from "@angular/cdk/layout";
import { Observable } from "rxjs";
import { map, shareReplay } from "rxjs/operators";
import { CommonService } from "../service/common.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-main-nav",
  templateUrl: "./main-nav.component.html",
  styleUrls: ["./main-nav.component.css"],
})
export class MainNavComponent implements OnInit {
  isHandset$: Observable<boolean> = this.breakpointObserver
    .observe([Breakpoints.Handset, Breakpoints.Tablet, Breakpoints.Web])
    .pipe(
      map((result) => result.matches),
      shareReplay()
    );

  enableAuth: boolean = false;

  constructor(
    private breakpointObserver: BreakpointObserver,
    public common: CommonService,
    public router: Router
  ) {}

  ngOnInit(): void {
    if (this.common.getMemberId() === 0) {
      this.enableAuth = false;
    } else {
      this.enableAuth = true;
    }
    this.common.cartRefresh();
    this.common.cartSummary();
  }

  logout(): void {
    localStorage.removeItem("regal_member_id");
    this.enableAuth = false;
    this.router.navigate(["homepage"]);
  }
}
