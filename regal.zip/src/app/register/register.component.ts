import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ViewChild } from "@angular/core";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"],
})
export class RegisterComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;

  name: string = "";
  emailId: string = "";
  mobileNumber: string = "";
  password: string = "";

  inValidName: boolean = false;
  inValidEmailId: boolean = false;
  inValidMobileNumber: boolean = false;
  inValidPassword: boolean = false;
  inValidConfirmPassword: boolean = false;

  unUseName: boolean = true;
  unUseEmailId: boolean = true;
  unUseMobileNumber: boolean = true;
  unUsePassword: boolean = true;
  unUseConfirmPassword: boolean = true;

  loading: boolean = false;
  status: string = "";
  message: string = "";
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
  }

  onKeyUp(event: any, property: string): void {
    if (property === "name") {
      if (event.target.value === "") {
        this.name = "";
        this.inValidName = true;
        this.unUseName = true;
      } else {
        this.name = event.target.value;
        this.inValidName = false;
        this.unUseName = false;
      }
    }

    if (property === "emailId") {
      if (!/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(event.target.value)) {
        this.emailId = "";
        this.inValidEmailId = true;
        this.unUseEmailId = true;
      } else {
        this.emailId = event.target.value;
        this.inValidEmailId = false;
        this.unUseEmailId = false;
      }
    }

    if (property === "mobileNumber") {
      if (!/^[0-9]*$/.test(event.target.value) || event.target.value === "") {
        this.mobileNumber = "";
        this.inValidMobileNumber = true;
        this.unUseMobileNumber = true;
      } else {
        this.mobileNumber = event.target.value;
        this.inValidMobileNumber = false;
        this.unUseMobileNumber = false;
      }
    }

    if (property === "password") {
      if (event.target.value === "") {
        this.password = "";
        this.inValidPassword = true;
        this.unUsePassword = true;
      } else {
        this.password = event.target.value;
        this.inValidPassword = false;
        this.unUsePassword = false;
      }
    }

    if (property === "confirmPassword") {
      if (this.password !== event.target.value) {
        this.inValidConfirmPassword = true;
        this.unUseConfirmPassword = true;
      } else {
        this.inValidConfirmPassword = false;
        this.unUseConfirmPassword = false;
      }
    }
  }

  register(event: any): void {
    try {
      event.preventDefault();
      this.loading = true;
      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "Register",
        Name: this.name,
        EmailId: this.emailId,
        PhoneNo: this.mobileNumber,
        password: this.password,
        gcm_id: "",
        type: "Android",
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { status }: any = res;
        if (status === "success") {
          const { mem_id }: any = res;
          localStorage.setItem("regal_member_id", mem_id);
          this.router.navigate(["homepage"]);
        } else {
          this.message = status;
        }
        this.loading = false;
      });
    } catch (error) {
      this.loading = false;
      this.errMsg = error;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }
}
