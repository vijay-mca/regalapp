import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-card-payment",
  templateUrl: "./card-payment.component.html",
  styleUrls: ["./card-payment.component.css"],
})
export class CardPaymentComponent implements OnInit {
  @ViewChild("successModal") private successModalRef: any;
  @ViewChild("errorModal") private errorModalRef: any;

  nameOnCard: string = "";
  cardNumber: string = "";
  cardBrand: string = "";
  expiryMonth: string = "";
  expiryYear: string = "";
  cardCvv: string = "";
  amount: any = "";

  brandNames: any = [];

  inValidNameOnCard: boolean = false;
  inValidCardNumber: boolean = false;
  inValidCardBrand: boolean = false;
  inValidExpiryMonth: boolean = false;
  inValidExpiryYear: boolean = false;
  inValidCardCvv: boolean = false;

  unUseNameOnCard: boolean = true;
  unUseCardNumber: boolean = true;
  unUseCardBrand: boolean = true;
  unUseExpiryMonth: boolean = true;
  unUseExpiryYear: boolean = true;
  unUseCardCvv: boolean = true;

  loading: boolean = false;
  status: string = "";
  message: any = "";
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private actRoute: ActivatedRoute,
    private modalService: NgbModal,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.totalPaymentCardBrands();
  }

  onKeyUp(event: any, property: string): void {
    if (property === "nameOnCard") {
      if (event.target.value === "") {
        this.nameOnCard = "";
        this.inValidNameOnCard = true;
        this.unUseNameOnCard = true;
      } else {
        this.nameOnCard = event.target.value;
        this.inValidNameOnCard = false;
        this.unUseNameOnCard = false;
      }
    }

    if (property === "cardNumber") {
      if (event.target.value === "") {
        this.cardNumber = "";
        this.inValidCardNumber = true;
        this.unUseCardNumber = true;
      } else if (!/^[0-9]*$/.test(event.target.value)) {
        this.cardNumber = "";
        this.inValidCardNumber = true;
        this.unUseCardNumber = true;
      } else if (event.target.value.length !== 16) {
        this.cardNumber = event.target.value;
        this.inValidCardNumber = true;
        this.unUseCardNumber = true;
      } else {
        this.cardNumber = event.target.value;
        this.inValidCardNumber = false;
        this.unUseCardNumber = false;
      }
    }

    if (property === "cardBrand") {
      if (event.target.value === "") {
        this.cardBrand = "";
        this.inValidCardBrand = true;
        this.unUseCardBrand = true;
      } else {
        this.cardBrand = event.target.value;
        this.inValidCardBrand = false;
        this.unUseCardBrand = false;
      }
    }

    if (property === "expiryMonth") {
      if (event.target.value === "") {
        this.expiryMonth = "";
        this.inValidExpiryMonth = true;
        this.unUseExpiryMonth = true;
      } else if (!/^(0[1-9])|(1[012])$/.test(event.target.value)) {
        this.expiryMonth = "";
        this.inValidExpiryMonth = true;
        this.unUseExpiryMonth = true;
      } else if (event.target.value.length !== 2) {
        this.expiryMonth = event.target.value;
        this.inValidExpiryMonth = true;
        this.unUseExpiryMonth = true;
      } else {
        this.expiryMonth = event.target.value;
        this.inValidExpiryMonth = false;
        this.unUseExpiryMonth = false;
      }
    }

    if (property === "expiryYear") {
      if (event.target.value === "") {
        this.expiryYear = "";
        this.inValidExpiryYear = true;
        this.unUseExpiryYear = true;
      } else if (!/^[0-9]*$/.test(event.target.value)) {
        this.expiryYear = "";
        this.inValidExpiryYear = true;
        this.unUseExpiryYear = true;
      } else if (event.target.value.length !== 4) {
        this.expiryYear = event.target.value;
        this.inValidExpiryYear = true;
        this.unUseExpiryYear = true;
      } else {
        this.expiryYear = event.target.value;
        this.inValidExpiryYear = false;
        this.unUseExpiryYear = false;
      }
    }

    if (property === "cardCvv") {
      if (event.target.value === "") {
        this.cardCvv = "";
        this.inValidCardCvv = true;
        this.unUseCardCvv = true;
      } else if (!/^[0-9]*$/.test(event.target.value)) {
        this.cardCvv = "";
        this.inValidCardCvv = true;
        this.unUseCardCvv = true;
      } else if (event.target.value.length !== 3) {
        this.cardCvv = event.target.value;
        this.inValidCardCvv = true;
        this.unUseCardCvv = true;
      } else {
        this.cardCvv = event.target.value;
        this.inValidCardCvv = false;
        this.unUseCardCvv = false;
      }
    }
  }

  totalProcessing(event: any) {
    try {
      this.loading = true;

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "TotalProcessingCardPayment",
        brand: this.cardBrand,
        pay_amount: this.common.orderTotal,
        cardNumber: this.cardNumber,
        cardExpiryMonth: this.expiryMonth,
        cardExpiryYear: this.expiryYear,
        cardCVV: this.cardCvv,
        customer_name: this.common.firstName,
        customer_email: this.common.emailId,
        customer_mobile: this.common.mobileNumber,
        customer_address: this.common.addressLine1,
        customer_postcode: this.common.postCode,
        save_card: "No",
      };

      let headers: any = new HttpHeaders(REQUEST_HEADER);

      let options: any = {
        headers: headers,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const { status, curl_response }: any = res;

        if (status === "success") {
          const {
            redirect_url,
            para_name_1,
            para_val_1,
            para_name_2,
            para_val_2,
            para_name_3,
            para_val_3,
            temp_order_id,
          }: any = res;

          window.open(
            "https://regalcompetitions.com/tp-app-payment/payment.php?redirect_url=" +
              redirect_url +
              "&para_name_1=" +
              para_name_1 +
              "&para_val_1=" +
              para_val_1 +
              "&para_name_2=" +
              para_name_2 +
              "&para_val_2=" +
              para_val_2 +
              "&para_name_3=" +
              para_name_3 +
              "&para_val_3=" +
              para_val_3 +
              "&temp_order_id=" +
              temp_order_id +
              "",
            "payment",
            "width=700,location=no,menubar=no,height=500,scrollbars=no,resizable=no,fullscreen=no"
          );
          setInterval(() => {
            this.checkTPPaymentStatus(temp_order_id);
          }, 2000);
        } else {
          this.message = curl_response.result.description;
          this.modalService.open(this.successModalRef, {
            windowClass: "center-modal",
          });
        }

        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }

  totalPaymentCardBrands() {
    try {
      this.loading = true;

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "TotalPaymentCardBrands",
      };

      let headers: any = new HttpHeaders(REQUEST_HEADER);

      let options: any = {
        headers: headers,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const { brand_names }: any = res;
        this.brandNames = brand_names;
        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }

  checkTPPaymentStatus(temp_order_id: any) {
    try {
      this.loading = true;

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "CheckTPPaymentStatus",
        temp_order_id,
      };

      let headers: any = new HttpHeaders(REQUEST_HEADER);

      let options: any = {
        headers: headers,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res: any) => {
        const { status }: any = res;
        if (status === "success") {
          window.close();

          this.status = status;
          this.message = "Payment successfull";

          setTimeout(() => {
            this.modalService.open(this.successModalRef, {
              windowClass: "center-modal",
            });
          }, 2000);

          this.router.navigate(["homepage"]);
        }
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
  }
}
