import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MainNavComponent } from "./main-nav/main-nav.component";
import { LayoutModule } from "@angular/cdk/layout";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatButtonModule } from "@angular/material/button";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatIconModule } from "@angular/material/icon";
import { MatListModule } from "@angular/material/list";
import { MatBadgeModule } from "@angular/material/badge";
import { LoginComponent } from "./login/login.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { RegisterComponent } from "./register/register.component";
import { HomepageComponent } from "./homepage/homepage.component";
import { MyAccountComponent } from "./my-account/my-account.component";
import { CarouselModule } from "ngx-owl-carousel-o";
import { DetaisPageComponent } from "./detais-page/detais-page.component";
import { CartComponent } from "./cart/cart.component";
import { EntrylistComponent } from "./entrylist/entrylist.component";
import { WinnerGalleryComponent } from "./winner-gallery/winner-gallery.component";
import { AboutComponent } from "./about/about.component";
import { ContactComponent } from "./contact/contact.component";
import { CheckoutComponent } from "./checkout/checkout.component";
import { TermsComponent } from "./terms/terms.component";
import { HttpClientModule } from "@angular/common/http";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { LoaderComponent } from "./loader/loader.component";
import { InternetComponent } from "./internet/internet.component";
import { CardPaymentComponent } from "./card-payment/card-payment.component";
import { PolicyComponent } from "./policy/policy.component";

import { FirebaseX } from "@ionic-native/firebase-x/ngx";

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    LoginComponent,
    RegisterComponent,
    HomepageComponent,
    MyAccountComponent,
    DetaisPageComponent,
    CartComponent,
    EntrylistComponent,
    WinnerGalleryComponent,
    AboutComponent,
    ContactComponent,
    CheckoutComponent,
    TermsComponent,
    LoaderComponent,
    InternetComponent,
    CardPaymentComponent,
    PolicyComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatBadgeModule,
    CarouselModule,
    NgbModule,
    HttpClientModule,
    InfiniteScrollModule,
  ],
  providers: [FirebaseX],
  bootstrap: [AppComponent],
})
export class AppModule {}
