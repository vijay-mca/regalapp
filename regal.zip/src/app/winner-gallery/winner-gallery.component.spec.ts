import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WinnerGalleryComponent } from './winner-gallery.component';

describe('WinnerGalleryComponent', () => {
  let component: WinnerGalleryComponent;
  let fixture: ComponentFixture<WinnerGalleryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WinnerGalleryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WinnerGalleryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
