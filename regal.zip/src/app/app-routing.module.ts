import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AboutComponent } from "./about/about.component";
import { CardPaymentComponent } from "./card-payment/card-payment.component";
import { CartComponent } from "./cart/cart.component";
import { CheckoutComponent } from "./checkout/checkout.component";
import { PolicyComponent } from "./policy/policy.component";
import { ContactComponent } from "./contact/contact.component";
import { DetaisPageComponent } from "./detais-page/detais-page.component";
import { EntrylistComponent } from "./entrylist/entrylist.component";
import { HomepageComponent } from "./homepage/homepage.component";
import { LoginComponent } from "./login/login.component";
import { MainNavComponent } from "./main-nav/main-nav.component";
import { MyAccountComponent } from "./my-account/my-account.component";
import { RegisterComponent } from "./register/register.component";
import { TermsComponent } from "./terms/terms.component";
import { WinnerGalleryComponent } from "./winner-gallery/winner-gallery.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "homepage",
    pathMatch: "full",
  },
  {
    path: "login",
    component: LoginComponent,
    data: { title: "Login" },
  },

  {
    path: "register",
    component: RegisterComponent,
    data: { title: "Register" },
  },
  {
    path: "homepage",
    component: HomepageComponent,
    data: { title: "Homepage" },
  },
  {
    path: "my-account",
    component: MyAccountComponent,
    data: { title: "My-account" },
  },
  {
    path: "detais-page/:pro_id",
    component: DetaisPageComponent,
    data: { title: "Detais-page" },
  },
  { path: "cart", component: CartComponent, data: { title: "cart" } },
  {
    path: "entylist",
    component: EntrylistComponent,
    data: { title: "entrylist" },
  },
  {
    path: "winner-gallery",
    component: WinnerGalleryComponent,
    data: { title: "winner-gallery" },
  },
  {
    path: "about/:cms_id",
    component: AboutComponent,
    data: { title: "about" },
  },
  {
    path: "contact/:cms_id",
    component: ContactComponent,
    data: { title: "contact" },
  },
  {
    path: "checkout",
    component: CheckoutComponent,
    data: { title: "checkout" },
  },
  {
    path: "terms-condition/:cms_id",
    component: TermsComponent,
    data: { title: "terms" },
  },
  {
    path: "privacy-policy/:cms_id",
    component: PolicyComponent,
    data: { title: "terms" },
  },
  { path: "faqs/:cms_id", component: AboutComponent, data: { title: "faqs" } },
  { path: "main-nav", component: MainNavComponent },
  {
    path: "payment/:temp_order_id",
    component: CardPaymentComponent,
    data: { title: "Payment" },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
