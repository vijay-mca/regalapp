import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import {
  REQUEST_HEADER,
  AUTH_USERNAME,
  AUTH_PASSWORD,
  API,
} from "src/environments/environment";
import { CommonService } from "../service/common.service";

@Component({
  selector: "app-my-account",
  templateUrl: "./my-account.component.html",
  styleUrls: ["./my-account.component.css"],
})
export class MyAccountComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;
  countryOptions: any = [];

  firstName: string = "";
  lastName: string = "";
  emailId: string = "";
  mobileNumber: string = "";
  addressLine1: string = "";
  addressLine2: string = "";
  city: string = "";
  state: string = "";
  postCode: string = "";
  country: string = "";

  inValidFirstName: boolean = false;
  inValidLastName: boolean = false;
  inValidEmailId: boolean = false;
  inValidMobileNumber: boolean = false;
  inValidAddressLine1: boolean = false;
  inValidAddressLine2: boolean = false;
  inValidCity: boolean = false;
  inValidState: boolean = false;
  inValidPostCode: boolean = false;
  inValidCountry: boolean = false;

  unUseFirstName: boolean = true;
  unUseLastName: boolean = true;
  unUseEmailId: boolean = true;
  unUseMobileNumber: boolean = true;
  unUseAddressLine1: boolean = true;
  unUseAddressLine2: boolean = true;
  unUseCity: boolean = true;
  unUseState: boolean = true;
  unUsePostCode: boolean = true;
  unUseCountry: boolean = true;

  disableEmailId: boolean = false;

  status: string = "";
  message: string = "";

  loading: boolean = false;
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    public actRoute: ActivatedRoute,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
    this.myAccount();
  }

  myAccount(): void {
    try {
      this.loading = true;

      let headers = new HttpHeaders(REQUEST_HEADER);
      let options = { headers: headers };

      const post = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "MyAccount",
        member_id: this.common.getMemberId(),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { MemberDetails, country_options }: any = res;
        if (MemberDetails === false) {
          this.country = "";
          this.disableEmailId = false;
        } else {
          if (MemberDetails.mem_name === "") {
            this.unUseFirstName = true;
            this.firstName = "";
          } else {
            this.firstName = MemberDetails.mem_name;
            this.inValidFirstName = false;
            this.unUseFirstName = false;
          }

          if (MemberDetails.mem_lname === "") {
            this.unUseLastName = true;
            this.lastName = "";
          } else {
            this.lastName = MemberDetails.mem_lname;
            this.inValidLastName = false;
            this.unUseLastName = false;
          }

          if (
            !/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(
              MemberDetails.email_id
            )
          ) {
            this.emailId = "";
            this.unUseEmailId = true;
            this.disableEmailId = false;
          } else {
            this.emailId = MemberDetails.email_id;
            this.inValidEmailId = false;
            this.unUseEmailId = false;
            this.disableEmailId = true;
          }

          if (
            !/^[0-9]*$/.test(MemberDetails.mobile_no) ||
            MemberDetails.mobile_no === ""
          ) {
            this.unUseMobileNumber = true;
            this.mobileNumber = "";
          } else {
            this.mobileNumber = MemberDetails.mobile_no;
            this.inValidMobileNumber = false;
            this.unUseMobileNumber = false;
          }

          if (MemberDetails.address_line1 === "") {
            this.unUseAddressLine1 = true;
            this.addressLine1 = "";
          } else {
            this.addressLine1 = MemberDetails.address_line1;
            this.inValidAddressLine1 = false;
            this.unUseAddressLine1 = false;
          }

          if (MemberDetails.address_line2 === "") {
            this.unUseAddressLine2 = true;
            this.addressLine2 = "";
          } else {
            this.addressLine2 = MemberDetails.address_line2;
            this.inValidAddressLine2 = false;
            this.unUseAddressLine2 = false;
          }

          if (MemberDetails.city === "") {
            this.unUseCity = true;
            this.city = "";
          } else {
            this.city = MemberDetails.city;
            this.inValidCity = false;
            this.unUseCity = false;
          }

          if (MemberDetails.state === "") {
            this.unUseState = true;
            this.state = "";
          } else {
            this.state = MemberDetails.state;
            this.inValidState = false;
            this.unUseState = false;
          }

          if (
            MemberDetails.postcode === ""
          ) {
            this.unUsePostCode = true;
            this.postCode = "";
          } else {
            this.postCode = MemberDetails.postcode;
            this.inValidPostCode = false;
            this.unUsePostCode = false;
          }

          if (MemberDetails.country === "") {
            this.unUseCountry = true;
            this.country = "";
          } else {
            this.country = MemberDetails.country;
            this.inValidCountry = false;
            this.unUseCountry = false;
          }
        }

        this.countryOptions = country_options;

        this.loading = false;
      });
    } catch (error) {
      this.errMsg = error;
      this.loading = false;
      setTimeout(() => {
        this.modalService.open(this.errorModalRef, {
          windowClass: "center-modal",
        });
      }, 1000);
    }
    
  }

  onKeyUp(event: any, property: string): void {
    if (property === "firstName") {
      if (event.target.value === "") {
        this.inValidFirstName = true;
        this.unUseFirstName = true;
        this.firstName = "";
      } else {
        this.firstName = event.target.value;
        this.inValidFirstName = false;
        this.unUseFirstName = false;
      }
    }

    if (property === "lastName") {
      if (event.target.value === "") {
        this.inValidLastName = true;
        this.unUseLastName = true;
        this.lastName = "";
      } else {
        this.lastName = event.target.value;
        this.inValidLastName = false;
        this.unUseLastName = false;
      }
    }

    if (property === "emailId") {
      if (!/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(event.target.value)) {
        this.inValidEmailId = true;
        this.unUseEmailId = true;
        this.emailId = "";
      } else {
        this.emailId = event.target.value;
        this.inValidEmailId = false;
        this.unUseEmailId = false;
      }
    }

    if (property === "mobileNumber") {
      if (!/^[0-9]*$/.test(event.target.value) || event.target.value === "") {
        this.inValidMobileNumber = true;
        this.unUseMobileNumber = true;
        this.mobileNumber = "";
      } else {
        this.mobileNumber = event.target.value;
        this.inValidMobileNumber = false;
        this.unUseMobileNumber = false;
      }
    }

    if (property === "addressLine1") {
      if (event.target.value === "") {
        this.inValidAddressLine1 = true;
        this.unUseAddressLine1 = true;
        this.addressLine1 = "";
      } else {
        this.addressLine1 = event.target.value;
        this.inValidAddressLine1 = false;
        this.unUseAddressLine1 = false;
      }
    }

    if (property === "addressLine2") {
      if (event.target.value === "") {
        this.inValidAddressLine2 = true;
        this.unUseAddressLine2 = true;
        this.addressLine2 = "";
      } else {
        this.addressLine2 = event.target.value;
        this.inValidAddressLine2 = false;
        this.unUseAddressLine2 = false;
      }
    }

    if (property === "city") {
      if (event.target.value === "") {
        this.inValidCity = true;
        this.unUseCity = true;
        this.city = "";
      } else {
        this.city = event.target.value;
        this.inValidCity = false;
        this.unUseCity = false;
      }
    }

    if (property === "state") {
      if (event.target.value === "") {
        this.inValidState = true;
        this.unUseState = true;
        this.state = "";
      } else {
        this.state = event.target.value;
        this.inValidState = false;
        this.unUseState = false;
      }
    }

    if (property === "postCode") {
      if (!/^[0-9]*$/.test(event.target.value) || event.target.value === "") {
        this.inValidPostCode = true;
        this.unUsePostCode = true;
        this.postCode = "";
      } else {
        this.postCode = event.target.value;
        this.inValidPostCode = false;
        this.unUsePostCode = false;
      }
    }

    if (property === "country") {
      if (event.target.value === "") {
        this.inValidCountry = true;
        this.unUseCountry = true;
        this.country = "";
      } else {
        this.country = event.target.value;
        this.inValidCountry = false;
        this.unUseCountry = false;
      }
    }
  }

  updateAccount(event: any): void {
    try {
      this.loading = true;
      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "UpdateAccount",
        mem_name: this.firstName,
        mem_lname: this.lastName,
        mobile_no: this.mobileNumber,
        address_line1: this.addressLine1,
        city: this.city,
        state: this.state,
        postcode: this.postCode,
        country: this.country,
        member_id: this.common.getMemberId(),
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { status }: any = res;
        if (status === "success") {
          this.message = "Account updated";
          this.status = "success";
        } else {
          this.message = status;
          this.status = "danger";
        }
        this.loading = false;
      });
    } catch (error) {
      this.loading = false;
      this.errMsg = error;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }
}
