import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from "@angular/core";
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { REQUEST_HEADER, AUTH_USERNAME, AUTH_PASSWORD, API } from 'src/environments/environment';
import { CommonService } from '../service/common.service';

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  @ViewChild("errorModal") private errorModalRef: any;

  emailId: string = "";
  password: string = "";

  inValidEmailId: boolean = false;
  inValidPassword: boolean = false;

  unUseEmailId: boolean = true;
  unUsePassword: boolean = true;

  loading: boolean = false;
  status: string = "";
  message: string = "";
  errMsg: any = "";

  constructor(
    private http: HttpClient,
    public common: CommonService,
    private router: Router,
    private modalService: NgbModal
  ) {}

  ngOnInit(): void {
    this.common.cartRefresh();
    this.common.cartSummary();
  }

  onKeyUp(event: any, property: string): void {
    if (property === "emailId") {
      if (event.target.value === "") {
        this.inValidEmailId = true;
        this.unUseEmailId = true;
        this.emailId = "";
      } else {
        this.emailId = event.target.value;
        this.inValidEmailId = false;
        this.unUseEmailId = false;
      }
    }

    if (property === "password") {
      if (event.target.value === "") {
        this.inValidPassword = true;
        this.unUsePassword = true;
        this.password = "";
      } else {
        this.password = event.target.value;
        this.inValidPassword = false;
        this.unUsePassword = false;
      }
    }
  }

  login(event: any): void {
    try {
      event.preventDefault();
      this.loading = true;
      let headers: any = new HttpHeaders(REQUEST_HEADER);
      let options: any = {
        headers: headers,
      };

      const post: any = {
        auth_username: AUTH_USERNAME,
        auth_password: AUTH_PASSWORD,
        action: "Login",
        Email: this.emailId,
        password: this.password,
      };

      let formBody: any = this.common.convertUrlEncoded(post);

      this.http.post<any>(API, formBody, options).subscribe((res) => {
        const { status }: any = res;
        if (status === "success") {
          const { mem_id }: any = res;
          localStorage.setItem("regal_member_id", mem_id);
          this.router.navigate(["homepage"]);
        } else {
          this.message = status;
        }
        this.loading = false;
      });
    } catch (error) {
      this.loading = false;
      this.errMsg = error;
      this.modalService.open(this.errorModalRef, {
        windowClass: "center-modal",
      });
    }
  }
}
