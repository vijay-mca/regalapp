document.addEventListener(
  "deviceready",
  function () {
    var push = PushNotification.init({
      android: {
        senderID: "597544831166",
      },
      browser: {
        pushServiceURL: "http://push.api.phonegap.com/v1/push",
      },
      ios: {
        alert: "true",
        badge: "true",
        sound: "true",
        clearBadge: "true",
      },
      windows: {},
    });
    push.on("registration", function (data) {
      alert(data.registrationId);

      var gcmID = data.registrationId;
      var deviceType = "Android";
      var MemberId = "1"; //if not login send as 0
      //Send this to "PushNotification" action every time when app opens.
    });
    push.on("notification", function (data) {
      //alert(JSON.stringify(data));
    });
    push.on("error", function (e) {
      // e.message
    });
  },
  true
);
