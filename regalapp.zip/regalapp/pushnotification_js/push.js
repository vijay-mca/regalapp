setTimeout(() => {
  alert("push notification called. push.js");
  FirebasePlugin.getToken(
    function (fcmToken) {
      var fcm_token = fcmToken;

      alert("1=" + fcm_token);

      //send this fcm_token to action=PushNotification, gcmid=fcm_token, type=ios

      FirebasePlugin.grantPermission((hasPermission) => {
        alert("Permission was " + (hasPermission ? "granted" : "denied"));
      });
    },
    function (error) {
      alert("error = " + error);
    }
  );
}, 3000);
